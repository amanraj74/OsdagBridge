"""
Packaging utility to generate OsdagBridge_Testing_Submission.zip
For FOSSEE Osdag Winter Internship 2026 Screening Task
"""

import os
import zipfile
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parent.parent
ZIP_PATH = WORKSPACE / "OsdagBridge_Testing_Submission.zip"

print(f"Packaging submission into: {ZIP_PATH}")

files_to_include = []

# Testing directory contents
testing_dir = WORKSPACE / "testing"
for root, dirs, files in os.walk(testing_dir):
    for f in files:
        if f.endswith(('.pdf', '.tex', '.osi', '.json', '.log', '.md', '.py', '.png')):
            full_path = Path(root) / f
            arc_name = full_path.relative_to(WORKSPACE)
            files_to_include.append((full_path, arc_name))

# Add tools and root files
for extra in ["github_issues_all.json", "environment.yml", "README.md"]:
    p = WORKSPACE / extra
    if p.exists():
        files_to_include.append((p, Path(extra)))

# Add tools scripts
tools_dir = WORKSPACE / "tools"
if tools_dir.exists():
    for f in os.listdir(tools_dir):
        if f.endswith(".py"):
            p = tools_dir / f
            files_to_include.append((p, p.relative_to(WORKSPACE)))

with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as zipf:
    for full_path, arc_name in files_to_include:
        print(f"Adding: {arc_name}")
        zipf.write(full_path, arcname=str(arc_name))

print(f"\nSUCCESS: Created {ZIP_PATH} ({os.path.getsize(ZIP_PATH):,} bytes)")
