import json
import sys

keywords = sys.argv[1:] if len(sys.argv) > 1 else ["material"]
with open("github_issues_all.json", encoding="utf-8") as f:
    issues = json.load(f)

for iss in issues:
    title = iss.get("title", "")
    body = iss.get("body", "") or ""
    text = (title + " " + body).lower()
    if any(k.lower() in text for k in keywords):
        labels = [l["name"] for l in iss.get("labels", [])]
        print(f"#{iss['number']} [{iss['state']}]: {title}")
