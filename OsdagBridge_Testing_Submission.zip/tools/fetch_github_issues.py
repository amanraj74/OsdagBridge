import urllib.request
import json

url = 'https://api.github.com/repos/Nidhikhare12/OsdagBridge/issues?state=all&per_page=100'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
try:
    with urllib.request.urlopen(req) as resp:
        issues = json.loads(resp.read().decode('utf-8'))
        print(f"Total issues/PRs returned: {len(issues)}")
        for iss in issues:
            is_pr = "pull_request" in iss
            kind = "PR" if is_pr else "ISSUE"
            print(f"#{iss['number']}: [{iss['state']}] [{kind}] {iss['title']} (by {iss['user']['login']})")
except Exception as e:
    print("Error:", e)
