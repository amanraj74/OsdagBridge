import urllib.request
import json

all_issues = []
page = 1
while True:
    url = f'https://api.github.com/repos/Nidhikhare12/OsdagBridge/issues?state=all&per_page=100&page={page}'
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            if not data:
                break
            all_issues.extend(data)
            print(f"Page {page}: fetched {len(data)} items")
            if len(data) < 100:
                break
            page += 1
    except Exception as e:
        print("Error fetching page:", e)
        break

print(f"Total fetched: {len(all_issues)}")
with open("github_issues_all.json", "w", encoding="utf-8") as f:
    json.dump(all_issues, f, indent=2)
print("Saved to github_issues_all.json")
