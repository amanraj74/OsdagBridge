import traceback
import sys
from osdagbridge.core.bridge_types.plate_girder.defaults import BASIC_INPUT_DICT, solve_extend_basic_input_dict
from osdagbridge.core.bridge_types.plate_girder.plategirderbridge import PlateGirderBridge
import osdagbridge.core.utils.common as comm

inp = dict(BASIC_INPUT_DICT)
inp[comm.KEY_SPAN] = 30.0
inp[comm.KEY_CARRIAGEWAY_WIDTH] = 7.5
inp[comm.KEY_PROJECT_LOCATION] = 'Mumbai'
inp[comm.KEY_SKEW_ANGLE] = 0.0
inp[comm.KEY_FOOTPATH] = 'None'
inp[comm.KEY_INCLUDE_MEDIAN] = 'No'
inp[comm.KEY_MATERIAL_GIRDER_G] = 76.9

solve_extend_basic_input_dict(inp)

bridge = PlateGirderBridge()
bridge.set_input(inp)

# Run pre-stage conversions and stages up to stage 4
bridge._resolve_optimized_bounds_to_mm()
bridge._convert_girder_dims_mm_to_m()
bridge._validate_inputs()
bridge._solve_bridge_layout()
bridge._stage_grillage_setup()
bridge.add_dead_loads()
bridge.add_live_loads()
bridge.add_wind_loads()
bridge.add_temperature_load()
bridge.add_seismic_loads()
bridge._stage_load_combinations()
dataset = bridge._reanalyze_with_dedup()
dataset = bridge.create_envelope_load_case(dataset)
dataset = bridge._drop_moving_increment_cases(dataset)
bridge.memory.clear_intermediate_results()

print("Analysis done, now running _run_dcr_checks...")
try:
    bridge._run_dcr_checks(dataset)
    print("_run_dcr_checks SUCCEEDED!")
except Exception as e:
    with open("crash_traceback.txt", "w") as f:
        traceback.print_exc(file=f)
    traceback.print_exc()
