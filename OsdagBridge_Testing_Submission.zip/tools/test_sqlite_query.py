import sqlite3
from pathlib import Path

db_path = Path('src/osdagbridge/core/data/ResourceFiles/Intg_osdag.sqlite')
con = sqlite3.connect(db_path)
cur = con.cursor()
try:
    cur.execute('SELECT "Modulus of Elasticity" FROM Concrete_Grade_Properties WHERE "Grade" = ?', ('custom_steel_360_500',))
    print("Row:", cur.fetchone())
except Exception as e:
    print("Direct query exception:", type(e), e)
