import json

with open("testing/test_suite_summary.json") as f:
    summary = json.load(f)

for tc in summary:
    tc_id = tc["tc_id"]
    name = tc["tc_name"]
    status = tc["status"]
    print(f"[{tc_id}] {name}: Status = {status}")
    for r in tc["runs"]:
        idx = r["run_index"]
        elapsed = r.get("elapsed_seconds")
        dcr = r.get("max_dcr")
        cad = r.get("cad_params_generated")
        keys = r.get("output_keys_count")
        print(f"    Run {idx}: time={elapsed}s, max_dcr={dcr}, CAD={cad}, keys={keys}")
