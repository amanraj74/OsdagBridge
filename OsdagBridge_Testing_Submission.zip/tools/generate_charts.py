import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import json
import os

os.makedirs('testing/report/images', exist_ok=True)

with open('testing/test_suite_summary.json') as f:
    suite = json.load(f)

tc_ids = [tc['tc_id'] for tc in suite]
flexure = [tc['runs'][0]['util_flexure'] for tc in suite]
shear = [tc['runs'][0]['util_shear'] for tc in suite]
ltb = [tc['runs'][0]['util_ltb'] for tc in suite]
fatigue = [tc['runs'][0]['util_fatigue'] for tc in suite]
deflection = [tc['runs'][0]['util_deflection'] for tc in suite]

x = np.arange(len(tc_ids))
width = 0.15

fig, ax = plt.subplots(figsize=(10, 4.8), dpi=300)

ax.bar(x - 2*width, flexure, width, label='Flexure (ULS)', color='#2b5c8f')
ax.bar(x - width, shear, width, label='Shear (ULS)', color='#4682b4')
ax.bar(x, ltb, width, label='LTB (ULS)', color='#5f9ea0')
ax.bar(x + width, deflection, width, label='Deflection (SLS)', color='#8fbc8f')
ax.bar(x + 2*width, fatigue, width, label='Fatigue (IRC:22 Cl. 605.4)', color='#d9534f')

ax.axhline(100.0, color='red', linestyle='--', linewidth=1.5, label='Code Limit (100% / DCR = 1.0)')

ax.set_xlabel('Test Case ID', fontweight='bold', fontsize=10)
ax.set_ylabel('Utilization Ratio (%)', fontweight='bold', fontsize=10)
ax.set_title('Structural Utilization Across Test Scenarios (Software PASS vs. Structural Check)', fontweight='bold', fontsize=11)
ax.set_xticks(x)
ax.set_xticklabels(tc_ids, fontweight='bold')
ax.set_ylim(0, 180)
ax.grid(True, linestyle='--', alpha=0.5)
ax.legend(loc='upper right', frameon=True, fontsize=8)
plt.tight_layout()
plt.savefig('testing/report/images/fig7_dcr_utilization_chart.png')
plt.close()

# Figure 8: Consecutive Run Unit Division Collapse
runs = ['Initial UI', 'Run 1', 'Run 2 (Bug)', 'Run 3 (Bug)']
depths = [1670.0, 1.67, 0.00167, 0.00000167]

fig, ax1 = plt.subplots(figsize=(8, 4.2), dpi=300)
colors = ['#2b5c8f', '#2b5c8f', '#d9534f', '#d9534f']
bars = ax1.bar(runs, depths, bottom=1e-7, color=colors, width=0.45)
ax1.set_yscale('log')
ax1.set_ylabel('Total Girder Depth D (mm, log scale)', fontweight='bold', color='#2b5c8f')
ax1.set_title('In-Place Unit Division Degradation Across Consecutive Design Runs', fontweight='bold', fontsize=11)

for bar, d in zip(bars, depths):
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2.0, max(d, 1e-6) * 2.0, f'{d:.6g} mm', ha='center', va='bottom', fontsize=9, fontweight='bold')

ax1.axhline(44.0, color='orange', linestyle='--', linewidth=1.5, label='Flange Thickness Sum (tf,top + tf,bot = 44 mm)')
ax1.grid(True, which='both', linestyle=':', alpha=0.4)
ax1.legend(loc='upper right')
ax1.set_ylim(1e-7, 1e4)
plt.tight_layout()
plt.savefig('testing/report/images/fig8_multi_run_unit_division.png')
plt.close()

print('Charts generated successfully!')
